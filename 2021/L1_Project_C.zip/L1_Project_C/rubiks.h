#ifndef L1_PROJECT_C_RUBIKS_H
#define L1_PROJECT_C_RUBIKS_H

typedef enum { FRONT, BACK, UP, DOWN, RIGHT, LEFT } T_SIDE ; //Faces du Rubik's Cube
typedef enum { R, B, G, W, Y, O } T_COLOR ;                  //Couleurs du Rubik's Cube

typedef struct RBK {
    T_SIDE Type_face ;
    T_COLOR Face[3][3] ;
} T_RUBIKS ;

T_COLOR select_color(T_COLOR c) ;
int side_to_index(T_SIDE Type_face) ;

void create_rubiks() ;
void init_rubiks(T_RUBIKS *Cube[]) ;
void display_rubiks(T_RUBIKS Cube[]) ;

#endif //L1_PROJECT_C_RUBIKS_H