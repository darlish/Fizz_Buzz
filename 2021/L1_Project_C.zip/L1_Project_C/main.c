#include "rubiks.h"
#include "conio.h"
#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("%d", select_color(W)) ;
    printf("%", side_to_index(FRONT)) ;


    return 0;
}