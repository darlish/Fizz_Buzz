#include "rubiks.h"
#include "conio.h"
#include <stdlib.h>
#include <stdio.h>

T_COLOR select_color(T_COLOR c) {
    if(c == R) { return RED ; }
    if(c == B) { return BLUE ; }
    if(c == G) { return GREEN ; }
    if(c == W) { return WHITE ; }
    if(c == Y) { return YELLOW ; }
    if(c == O) { return LIGHTMAGENTA ; }
}

int side_to_index(T_SIDE Face) {
    if(Face == LEFT)  { return 0 ; }
    if(Face == UP)    { return 1 ; }
    if(Face == FRONT) { return 2 ; }
    if(Face == DOWN)  { return 3 ; }
    if(Face == RIGHT) { return 4 ; }
    if(Face == BACK)  { return 5 ; }
}

void create_rubiks() {
    T_RUBIKS ***Cube = (T_RUBIKS***) malloc(6*sizeof(T_RUBIKS**)) ;
    for(int i = 0; i < 6; i++) {
        *Cube[i] = (T_RUBIKS**) malloc(sizeof(T_SIDE*) + sizeof(T_COLOR*)) ;
    }
    for(int j = 0; j < 6; j++) {
        Cube[j] = (T_RUBIKS*) malloc(sizeof(T_COLOR)) ;
    }
}

void init_rubiks(T_RUBIKS *Cube[]) {
    Cube[0]->Type_face = side_to_index(LEFT) ;
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            Cube[0]->Face[i][j] = select_color(O) ;
        }
    }
    Cube[1]->Type_face = side_to_index(UP) ;
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            Cube[1]->Face[i][j] = select_color(W) ;
        }
    }
    Cube[2]->Type_face = side_to_index(FRONT) ;
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            Cube[2]->Face[i][j] = select_color(G) ;
        }
    }
    Cube[3]->Type_face = side_to_index(DOWN) ;
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            Cube[3]->Face[i][j] = select_color(Y) ;
        }
    }
    Cube[4]->Type_face = side_to_index(RIGHT) ;
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            Cube[4]->Face[i][j] = select_color(R) ;
        }
    }
    Cube[5]->Type_face = side_to_index(BACK) ;
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            Cube[5]->Face[i][j] = select_color(B) ;
        }
    }
}

void display_rubiks(T_RUBIKS Cube[]) {
    for(int i = 0; i < 6; i++) {
        printf("Face %u", Cube[i].Type_face) ;
        for(int j = 0; j < 3; j++) {
            for(int k = 0; k < 3; k++) {
                printf("%c", Cube[i].Face[j][k]) ;
            }
            printf("\n") ;
        }
    }
}